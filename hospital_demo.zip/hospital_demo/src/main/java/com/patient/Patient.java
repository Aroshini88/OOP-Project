package com.patient;

public class Patient {
	private int pid;
	private String p_name;
    private String p_age;
    private String blood_group;
    private String p_phone;
    
    public Patient(int pid, String p_name, String p_age, String blood_group, String p_phone) {
		super();
		this.pid = pid;
		this.p_name = p_name;
		this.p_age = p_age;
		this.blood_group = blood_group;
		this.p_phone = p_phone;
}



	public int getPid() {
		return pid;
	}


	public String getP_name() {
		return p_name;
	}

	public String getP_age() {
		return p_age;
	}


	public String getBlood_group() {
		return blood_group;
	}


	public String getP_phone() {
		return p_phone;
	}

	
}
