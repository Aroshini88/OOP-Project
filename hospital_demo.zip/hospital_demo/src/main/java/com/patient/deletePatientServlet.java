package com.patient;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/deletePatientServlet")
public class deletePatientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String pid = request.getParameter("pid");
		boolean isTrue;
		
		isTrue = patientDBUtil.deletepatient(pid);
		
		if (isTrue == true) {
			out.println("<script type='text/javascript'>");
			out.println("confirm('Patient deleted successfully');");
			out.println("location='godeletePatient.jsp'");
			out.println("</script>");
		}
		else {
			
			List<Patient> psDetails = patientDBUtil.getPatientDetails(pid);
			request.setAttribute("psDetails", psDetails);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("useraccount.jsp");
			dispatcher.forward(request, response);
		}
		
	}

}
