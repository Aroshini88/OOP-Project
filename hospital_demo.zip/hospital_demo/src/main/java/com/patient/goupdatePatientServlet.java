package com.patient;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/goupdatePatientServlet")
public class goupdatePatientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String Pid = request.getParameter("pid");
		boolean isTrue;
		
		isTrue = patientDBUtil.validate1(Pid);
		
		if (isTrue == true) {
			List<Patient> psDetails = patientDBUtil.getPatient1(Pid);
			request.setAttribute("psDetails", psDetails);
			
			RequestDispatcher dis = request.getRequestDispatcher("useraccount1.jsp");
			dis.forward(request, response);
		} else {
			out.println("<script type='text/javascript'>");
			out.println("alert('Your pid is incorrect');");
			out.println("alert('Enetered details are incorrect');");
			out.println("</script>");
		}
	}

}