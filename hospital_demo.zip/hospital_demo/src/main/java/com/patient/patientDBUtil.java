package com.patient;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class patientDBUtil {
	private static boolean isSuccess;
	private static Connection con = null;
	private static Statement stmt = null;
	private static ResultSet rs = null;
	
public static boolean validate(String userName, String password) {
		
		try {
			con = DBConnect.getConnection();
			stmt = con.createStatement();
			String sql = "select * from manager where username='"+userName+"' and password='"+password+"'";
			rs = stmt.executeQuery(sql);
			
			if (rs.next()) {
				isSuccess = true;
			} else {
				isSuccess = false;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess;
	}

public static List<Patient> getPatient(String userName) {
		
		ArrayList<Patient> patient = new ArrayList<>();
		
		try {
			
			con = DBConnect.getConnection();
			stmt = con.createStatement();
			String sql = "select * from patient where mid=1";
			rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				int pid = rs.getInt(1);
				String p_name = rs.getString(2);
				String p_age = rs.getString(3);
				String blood_group = rs.getString(4);
				String p_phone = rs.getString(5);
			
				
				Patient ps = new Patient(pid,p_name,p_age,blood_group,p_phone);
				patient.add(ps);
			}
			
		} catch (Exception e) {
			
		}
		
		return patient;	
	}

public static boolean insertpatient(String p_name, String p_age, String blood_group, String p_phone) {
	
	boolean isSuccess = false;
	
	try {
		con = DBConnect.getConnection();
		stmt = con.createStatement();
	    String sql = "insert into patient values (0,'"+p_name+"','"+p_age+"','"+blood_group+"','"+p_phone+"',1)";
		int rs = stmt.executeUpdate(sql);
		
		if(rs > 0) {
			isSuccess = true;
		} else {
			isSuccess = false;
		}
		
	}
	catch (Exception e) {
		e.printStackTrace();
	}
	
	return isSuccess;
}


public static boolean validate1(String Pid) {
		
		try {
			con = DBConnect.getConnection();
			stmt = con.createStatement();
			String sql = "select * from patient where pid='"+Pid+"'";
			rs = stmt.executeQuery(sql);
			
			if (rs.next()) {
				isSuccess = true;
			} else {
				isSuccess = false;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess;
	}

public static List<Patient> getPatient1(String Pid) {
		
		ArrayList<Patient> patient = new ArrayList<>();
		
		try {
			
			con = DBConnect.getConnection();
			stmt = con.createStatement();
			String sql = "select * from patient where pid='"+Pid+"'";
			rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				int pid = rs.getInt(1);
				String p_name = rs.getString(2);
				String p_age = rs.getString(3);
				String blood_group = rs.getString(4);
				String p_phone = rs.getString(5);
			
				
				Patient ps = new Patient(pid,p_name,p_age,blood_group,p_phone);
				patient.add(ps);
			}
			
		} catch (Exception e) {
			
		}
		
		return patient;	
	}



public static boolean updatePatient(String pid, String p_name, String p_age, String blood_group, String p_phone) {
	
	try {
		
		con = DBConnect.getConnection();
		stmt = con.createStatement();
		String sql = "update patient set p_name='"+p_name+"',p_age='"+p_age+"',blood_group='"+blood_group+"',p_phone='"+p_phone+"'"+ "where pid='"+pid+"'";
		int rs = stmt.executeUpdate(sql);
		
		if(rs > 0) {
			isSuccess = true;
		}
		else {
			isSuccess = false;
		}
		
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	
	return isSuccess;
}

public static List<Patient> getPatientDetails(String Pid) {
	
	int convertedID = Integer.parseInt(Pid);
	
	ArrayList<Patient> patient = new ArrayList<>();
	
	try {
		
		con = DBConnect.getConnection();
		stmt = con.createStatement();
		String sql = "select * from patient where id='"+convertedID+"'";
		rs = stmt.executeQuery(sql);
		
		while(rs.next()) {
			int pid = rs.getInt(1);
			String p_name = rs.getString(2);
			String p_age = rs.getString(3);
			String blood_group = rs.getString(4);
			String p_phone = rs.getString(5);
			
			Patient ps = new Patient(pid,p_name, p_age, blood_group, p_phone);
			patient.add(ps);
		}
		
	}
	catch(Exception e) {
		e.printStackTrace();
	}	
	return patient;	
}

public static boolean deletepatient(String pid) {
	
	int convId = Integer.parseInt(pid);
	
	try {
		
		con = DBConnect.getConnection();
		stmt = con.createStatement();
		String sql = "delete from patient where pid='"+convId+"'";
		int r = stmt.executeUpdate(sql);
		
		if (r > 0) {
			isSuccess = true;
		}
		else {
			isSuccess = false;
		}
		
	}
	catch (Exception e) {
		e.printStackTrace();
	}
	
	return isSuccess;
}

}
