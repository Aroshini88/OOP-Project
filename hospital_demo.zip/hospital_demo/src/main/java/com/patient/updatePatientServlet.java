package com.patient;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/updatePatientServlet")
public class updatePatientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		
		String pid = request.getParameter("pid");
		String p_name = request.getParameter("p_name");
		String p_age = request.getParameter("p_age");
		String blood_group = request.getParameter("blood_group");
		String p_phone = request.getParameter("p_phone");
		
		boolean isTrue;
		
		isTrue = patientDBUtil.updatePatient(pid, p_name, p_age, blood_group, p_phone);
		
		if(isTrue == true) {
			
			List<Patient> psDetails = patientDBUtil.getPatientDetails(pid);
			request.setAttribute("psDetails", psDetails);
			
			out.println("<script type='text/javascript'>");
			out.println("confirm('Data updated successfully');");
			out.println("location='goupdatePatient.jsp'");
			out.println("</script>");
		}
		else {
			List<Patient> psDetails = patientDBUtil.getPatientDetails(pid);
			request.setAttribute("psDetails", psDetails);
			
			RequestDispatcher dis = request.getRequestDispatcher("useraccount.jsp");
			dis.forward(request, response);
		}
	}
		
		
}


